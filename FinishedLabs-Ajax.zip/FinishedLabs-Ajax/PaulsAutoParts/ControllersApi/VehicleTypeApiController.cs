﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.Common;
using PaulsAutoParts.DataLayer;
using PaulsAutoParts.EntityLayer;

namespace PaulsAutoParts.ControllersApi
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class VehicleTypeApiController : AppController
  {
    #region Constructor
    public VehicleTypeApiController(AppSession session,
           IRepository<VehicleType, VehicleTypeSearch> repo) : base(session)
    {
      _repo = repo;
    }
    #endregion

    #region Private Fields      
    private readonly IRepository<VehicleType, VehicleTypeSearch> _repo;
    #endregion

    #region SearchMakes Method
    [HttpGet("{make}", Name = "SearchMakes")]
    public IActionResult SearchMakes(string make)
    {
      IActionResult ret;

      // Search for all makes matching inputs
      var list = ((VehicleTypeRepository)_repo).SearchMakes(make);

      // Return all makes found
      ret = StatusCode(StatusCodes.Status200OK, list);

      return ret;
    }
    #endregion

    #region SearchModels Method
    [HttpGet("{model}", Name = "SearchModels")]
    public IActionResult SearchModels(string model)
    {
      IActionResult ret;

      // Search for all models matching inputs
      var list = ((VehicleTypeRepository)_repo).SearchModels(model);

      // Return all models found
      ret = StatusCode(StatusCodes.Status200OK, list);

      return ret;
    }
    #endregion
  }
}
