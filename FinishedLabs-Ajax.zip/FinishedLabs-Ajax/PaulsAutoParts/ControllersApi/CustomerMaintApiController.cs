﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.Common;
using PaulsAutoParts.EntityLayer;
using PaulsAutoParts.ViewModelLayer;

namespace PaulsAutoParts.Controllers
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class CustomerMaintApiController : AppController
  {
    #region Constructor
    public CustomerMaintApiController(AppSession session,
             IRepository<Customer, CustomerSearch> repo) : base(session)
    {
      _repo = repo;
    }
    #endregion

    #region Private Fields
    private readonly IRepository<Customer, CustomerSearch> _repo;
    #endregion

    #region Delete Method
    [HttpDelete("{id}", Name = "Delete")]
    public IActionResult Delete(int id)
    {
      // Create view model and pass in repository
      CustomerViewModel vm = new(_repo);

      // Set "Common" View Model Properties from Session
      base.SetViewModelFromSession(vm, UserSession);

      // Call method to delete a record
      vm.Delete(id);

      return StatusCode(StatusCodes.Status200OK, true);
    }
    #endregion
  }
}
