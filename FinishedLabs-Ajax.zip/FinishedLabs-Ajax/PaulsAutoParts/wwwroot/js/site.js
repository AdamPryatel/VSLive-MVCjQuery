﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
'use strict';

// ************************************
// Create a Closure
// ************************************
var mainController = (function () {
  // ************************************
  // Private Variables
  // ************************************
  let searchValues = null;

  // ************************************
  // Private Functions
  // ************************************
  function pleaseWait(ctl) {
    // Was a control passed in?
    if (ctl) {
      // Look for a data-waitmsg="message"
      // on the control clicked on
      let msg = $(ctl).data("waitmsg");
      if (msg) {
        $("#theWaitMessage").html(msg);
      }
    }

    $("#pleaseWait").removeClass("d-none");
    $("header").addClass("pleaseWaitArea");
    $("main").addClass("pleaseWaitArea");
    $("footer").addClass("pleaseWaitArea");

    disableAllClicks();
  }

  function disableAllClicks() {
    // Change all link cursors to an arrow and
    // disable all click events
    $("a").css("cursor", "arrow").click(false);
    // Disable all <input type="button"> elements
    $("input[type='button']").attr("disabled", "disabled");
    // Disable all <button> elements
    $("button").attr("disabled", "disabled");
  }

  function setSearchValues(value) {
    searchValues = value;
  }

  function isSearchFilledIn() {
    return searchValues;
  }

  function setSearchArea() {
    $("#searchBody").collapse(isSearchFilledIn() ? "show" : "hide");
  }

  function modifyItemsInCartText(isAdding) {
    // Get text from <a> tag
    let value = $("#itemsInCart").text();
    let count = 0;
    let pos = 0;

    if (value) {
      // Find the space in the text
      pos = value.indexOf(" ");
      // Get the total # of items
      count = parseInt(value.substring(0, pos));
      // Increment or Decrement the total # of items
      if (isAdding) {
        count++;
      }
      else {
        count--;
      }

      // Create the text with the new count
      value = count.toString() + " " + value.substring(pos);
      // Put text back into the cart
      $("#itemsInCart").text(value);
    }
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    "pleaseWait": pleaseWait,
    "disableAllClicks": disableAllClicks,
    "setSearchValues": setSearchValues,
    "isSearchFilledIn": isSearchFilledIn,
    "setSearchArea": setSearchArea,
    "modifyItemsInCartText": modifyItemsInCartText
  }
})();
