﻿namespace PaulsAutoParts.Common
{
  public class SearchBase
  {
    public SearchBase()
    {
      NoFilterAppliedMessage = "(none)";
    }

    public string NoFilterAppliedMessage { get; set; }
  }
}
