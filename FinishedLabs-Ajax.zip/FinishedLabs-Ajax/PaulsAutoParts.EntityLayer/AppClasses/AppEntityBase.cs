﻿using PaulsAutoParts.Common;

namespace PaulsAutoParts.EntityLayer
{
  public class AppEntityBase : EntityBase
  {
  }
}
